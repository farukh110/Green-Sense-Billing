$(document).ready( function () 
{
    $('#patient-data').DataTable();
} );