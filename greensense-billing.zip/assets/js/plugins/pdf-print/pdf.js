$(document).ready(function() 
{
    $(".btn-print").click(function() 
    {
    	$("#div_to_print1,#div_to_print2,#div_to_print3").printElement({});
    });	
});